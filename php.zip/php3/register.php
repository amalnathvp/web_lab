<?php>
session_start();
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "student_app";

$conn_mysql_connect($hostnmae, $username, $password, $dbname);
if(! $conn){
	die("connection failed: ".mysqli_connect_error());
	}

if($_server["REQUEST_METHOD"]=="post"){
	$first_name = $_post["first_name"];
	$last_name = $_post["last_name"];
	$dob = $_post["dob"];
	$email = $_post["email"];
	$mobile = $_post["mobile"];
	$gender = $_post["gender"];
	$password = $_post["password"];
	
	sql = "insert int students(first_name, last_name, dob, email, mobile, gender, password)values($firstname, $lastname, $dob, $email, $mobile, $gender, $password);
	
if($conn->($sql){
	echo "registration success <a href="login.php">login</a>";
	}else{
		echo "error: " $conn -> error;
		}
	}
}
?>


<form method="post">
	<label>first name: <input type = "text" name= "first_name" required></label><br>
	<label>last name: <input type = "text" name= "last_name" required></label><br>
	<label>Date of Birth: <input type = "date" name = "date" required> </label><br>
	<label>Email: <input type = "email" name = "email" required> </label> <br>
	<label>Mobile: <input type = "number" name = "mobile" required></label> <br>
	</label> <br>
	<label> gender: 
	<input type="radio" name = "gender" value ="male" required>
	Male
	<input type = "radio" name = "gender" value = "female" required> female </label> <br>
	<label>password<input type ="password" name = "password" required> </label><br>
	
	<button type = "submit"> register </button>
	</form>
	
	
